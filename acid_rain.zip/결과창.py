from tkinter import *
from tkinter.messagebox import *
import csv

class outputUI():
    def __init__(self,parent):
        self.parent=parent
        self.initUI()
        
    def initUI(self):
        #결과 윈도
        self.parent.geometry('500x550+700+300')
        self.parent.resizable(width=FALSE,height=FALSE)
        self.parent.title('결과')

        #처음으로 버튼
        self.tomain=Button(self.parent,text='처음으로',width=18,height=3,
                                command=self.tomain)
        self.tomain.place(relx=.05,rely=.85)

        #다시하기 버튼
        self.restart=Button(self.parent,text='다시하기',width=18,height=3,
                                command=self.restart)
        self.restart.place(relx=.35,rely=.85)
        
        #종료 버튼
        self.quit31=Button(self.parent,text='게임 종료',width=18,height=3,
                           command=self.quit)
        self.quit31.place(relx=.65,rely=.85)
        
    def tomain(self):
        global main_1
        main_1=1
        self.parent.destroy()
        
    def restart(self):
        global main_2
        main_2=1
        self.parent.destroy()
        
    def quit(self):
        yn=askyesno('게임종료','게임을 종료하시겠습니까?')
        if yn==1:
            self.parent.destroy()
            
def output():
    window31=Tk()
    outputUI(window31)
    frame31=Frame(window31,bg='yellow',width=400,height=400)
    frame31.pack(fill=X,expand=True,pady=50)
    frame31.pack_propagate(0)
    
    lbl1=Label(frame31,text='순위표',width=10)
    lbl1.config(font=('',25,'bold'))
    lbl1.pack()

    lbl2=Label(frame31,text='\n이름           점수          시간')
    lbl2.config(font=('',18,'bold'))
    lbl2.pack(side='top')
    
    def history():
        
        f=open('./output.csv','r')
        reader=csv.reader(f)
        
        ### 방금의 게임에서 이름과 점수를 받아서 csv에 넣는데,
        ### 1. 이미 있는 이름에 점수가 더 높으면 덮어씌우고 (날짜까지)
        ###    점수가 더 낮으면 csv에 넣지않음.
        ### 2. 새로운 이름으로 한 경우엔, 이름,점수,날짜 모두 csv에 추가해야함
        ### 3. 경우에 따라 csv파일에서 행의 길이가 다르기때문에 나눠서 해야할듯
        
        data=[]
        for i in reader:
            data.append(i)
        f.close()

        idx=[]
        for i in range(3,len(data[0]),3):
            idx.append(i)

        compare=[]
        for j in idx:
            compare.append((data[0][j]))
        sorted_compare=sorted(compare,reverse=True)[0:3]

        idx=[]
        playername=[]
        writtenscore=[]
        writtentime=[]
        
        for k in range(0,3):
            idx.append(data[0].index(sorted_compare[k]))
            playername.append(data[0][idx[k]-1])
            writtenscore.append(int(data[0][idx[k]]))
            writtentime.append(data[0][idx[k]+1])
        
        return playername,writtenscore,writtentime
    totalrank=history()

    rank1=Label(frame31,text='\n\n1등      %s'%totalrank[0][0]+'             %s'%totalrank[1][0]+'         %s'%totalrank[2][0])
    rank1.config(font=('',16,'bold'))
    rank1.pack(side='top')

    rank2=Label(frame31,text='\n\n2등      %s'%totalrank[0][1]+'             %s'%totalrank[1][1]+'         %s'%totalrank[2][1])
    rank2.config(font=('',16,'bold'))
    rank2.pack(side='top')

    
    rank3=Label(frame31,text='\n\n3등      %s'%totalrank[0][2]+'             %s'%totalrank[1][2]+'         %s'%totalrank[2][2]+'\n')
    rank3.config(font=('',16,'bold'))
    rank3.pack(side='top')
    
    window31.mainloop()
output()
