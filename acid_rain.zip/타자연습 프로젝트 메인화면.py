from tkinter import *
from tkinter.messagebox import *

class mainUI():
    def __init__(self,parent):
        self.parent=parent
        self.initUI()
        
    def initUI(self):
        #메인 윈도
        self.parent.geometry('500x550+100+100')
        self.parent.resizable(width=FALSE,height=FALSE)
        self.parent.title('오지는 타자연습')
        

        # 라벨1
        self.label11=Label(self.parent,text='오지는 타자연습',font=('돋움',30))
        self.label11.place(relx=.2,rely=.15)

        # 라벨2
        self.label21=Label(self.parent,text='단어세트 선택')
        self.label21.place(relx=.14,rely=.48)

        # 단어세트 listbox
        self.menubt11=Listbox(self.parent, height=0,selectmode=SINGLE)
        self.menubt11.insert(1,'초등학교 수준')
        self.menubt11.insert(2,'중학교 수준')
        self.menubt11.place(relx=.35,rely=.45)

        # 사용자이름 & 빈칸
        self.name11=Label(self.parent,text='사용자 이름')
        self.nameet11=Entry(self.parent)
        self.name11.place(relx=.15,rely=.6)
        self.nameet11.place(relx=.35,rely=.6)

        # 중복확인 버튼
        self.check11=Button(self.parent,text='중복확인',command=self.namecheck)
        self.check11.place(relx=.68,rely=.595)

        # 게임 방법
        self.howtoplay11=Button(self.parent,text='게임 방법',width=18,height=3,
                                command=self.howtoplay)
        self.howtoplay11.place(relx=.05,rely=.75)
        
        # 시작 버튼
        self.start11=Button(self.parent,text='게임 시작',width=18,height=3)
        self.start11.place(relx=.35,rely=.75)

        # 종료 버튼
        self.quit11=Button(self.parent,text='게임 종료',width=18,height=3,
                           command=self.quit)
        self.quit11.place(relx=.65,rely=.75)
        
    def namecheck(self):
        file=open('user.txt','r',encoding='utf-8')
        file.readline()
        name=file.readline().split()
        global input1
        global inputname
        input1=self.nameet11.get()
        tf=any(x in input1 for x in name)
        if input1=='':
            showerror('중복확인','이름은 필수 값입니다.')
        else:
            if tf==False:
                showinfo('중복확인','해당 이름은 사용 가능합니다.')
            else:
                showerror('중복확인','해당 이름은 사용할 수 없습니다.\n다른 이름을 사용해주세요.')

    def howtoplay(self):
        self.popup11=Toplevel(self.parent)
        self.popup11.title('게임 방법')
        self.popup11.geometry('595x632+200+200')

        img11=PhotoImage(file='./howtoplay.gif')
        lbl11=Label(self.popup11,image=img11)
        lbl11.place(x=0,y=0)
        self.popup11.mainloop()

    def quit(self):
        yn=askyesno('게임종료','게임을 종료하시겠습니까?')
        if yn==1:
            self.parent.destroy()

def main():
    window11=Tk()
    app11=mainUI(window11)
    window11.mainloop()

if __name__=='__main__':
    main()

